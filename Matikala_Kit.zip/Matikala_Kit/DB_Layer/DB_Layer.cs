﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using REDMIS.Models;

namespace REDMIS.DBLayer
{
    public class DB_Layer : DbContext
    {
        #region Basic
        public IEnumerable<Master> Proc_BindMaster(int ProcID)
        {
            var query = @"Proc_BindMaster @ProcId";
            var param = new SqlParameter[] {
            new SqlParameter{ParameterName="@ProcId",Value=ProcID}};
            return this.Database.SqlQuery<Master>(query, param);
        }
        public IEnumerable<ProjectMaster> Proc_GetProjectData(int ProcID, int Work_ID)
        {
            var query = @"Proc_GetProjectData @ProcId,@Work_ID";
            var param = new SqlParameter[] {
            new SqlParameter{ParameterName="@ProcId",Value=ProcID},
            new SqlParameter{ParameterName="@Work_ID",Value=Work_ID}};
            return this.Database.SqlQuery<ProjectMaster>(query, param);
        }
        public IEnumerable<Master> Proc_BindMasterById(int ProcID, int value)
        {
            var query = @"Proc_BindMasterById @ProcID,@id";
            var param = new SqlParameter[] {
            new SqlParameter{ParameterName="@ProcID",Value=ProcID},
            new SqlParameter{ParameterName="@id",Value=value}};
            return this.Database.SqlQuery<Master>(query, param);
        }
        public IEnumerable<Master> Proc_BindMasterByTwoId(int ProcID, int value, int value1)
        {
            var query = @"Proc_BindMasterByTwoId @ProcID,@id1,@id2";
            var param = new SqlParameter[] {
            new SqlParameter{ParameterName="@ProcID",Value=ProcID},
            new SqlParameter{ParameterName="@id1",Value=value},
            new SqlParameter{ParameterName="@id2",Value=value1}};
            return this.Database.SqlQuery<Master>(query, param);
        }
        public IEnumerable<Master> Proc_BindMasterByOffice(int ProcID, int value, int Office)
        {
            var query = @"Proc_BindMasterByOffice @ProcID,@id,@Officeid";
            var param = new SqlParameter[] {
            new SqlParameter{ParameterName="@ProcID",Value=ProcID},
            new SqlParameter{ParameterName="@id",Value=value},
            new SqlParameter{ParameterName="@Officeid",Value=Office}};
            return this.Database.SqlQuery<Master>(query, param);
        }
        //public virtual IEnumerable<UserLogin> GetPasswrdDetails(UserLogin Model)
        //{
        //    var sqlParams = new SqlParameter[]{
        //    new SqlParameter { ParameterName = "@UserName", Value = Model.Email??string.Empty },
        //    new SqlParameter { ParameterName = "@Password", Value = Model.UPassword??string.Empty },
        //    new SqlParameter { ParameterName = "@ProcID", Value = Model.ProcId},
        //    new SqlParameter { ParameterName = "@UTypeId", Value = Model.UserType==null?0:Model.UserType},
        //    };
        //    var sqlQaury = @"Proc_CheckUser @UserName,@Password,@ProcID,@UTypeId";
        //    var IList = this.Database.SqlQuery<UserLogin>(sqlQaury, sqlParams);
        //    return IList;
        //}
        public virtual IEnumerable<Login> Proc_CheckUser(Login Model)
        {
            var sqlParams = new SqlParameter[]{
            new SqlParameter { ParameterName = "@UserName", Value = Model.UserName??string.Empty },
            new SqlParameter { ParameterName = "@Password", Value = Model.Password??string.Empty },
            new SqlParameter { ParameterName = "@ProcId", Value = Model.ProcId==null?0:Model.ProcId},
            };
            var sqlQaury = @"Proc_CheckUserForCMIS @UserName,@Password,@ProcId";
            var IList = this.Database.SqlQuery<Login>(sqlQaury, sqlParams);
            return IList;
        }
        public virtual IEnumerable<ProjectMaster> Proc_CMISProjectMaster(ProjectMaster Model)
        {
            var sqlParams = new SqlParameter[]{
            new SqlParameter { ParameterName = "@Work_ID", Value = Model.Work_ID==null?0:Model.Work_ID},
            new SqlParameter { ParameterName = "@Program_ID", Value = Model.Program_ID==null?0:Model.Program_ID},
            new SqlParameter { ParameterName = "@Division_ID", Value = Model.Division_ID==null?0:Model.Division_ID},
            new SqlParameter { ParameterName = "@Work_Type_ID", Value = Model.Work_Type_ID==null?0:Model.Work_Type_ID},
            new SqlParameter { ParameterName = "@ZoneId", Value = Model.ZoneId==null?0:Model.ZoneId},
            new SqlParameter { ParameterName = "@CircleId", Value = Model.CircleId==null?0:Model.CircleId},
            new SqlParameter { ParameterName = "@DepartmentId", Value = Model.DepartmentId==null?0:Model.DepartmentId},
            new SqlParameter { ParameterName = "@VikasKhand_ID", Value = Model.VikasKhand_ID==null?0:Model.VikasKhand_ID},
            new SqlParameter { ParameterName = "@Work_Name", Value = Model.Work_Name??string.Empty },
            new SqlParameter { ParameterName = "@NoOfWork", Value = Model.NoOfWork==null?0:Model.NoOfWork},
            new SqlParameter { ParameterName = "@Length_QTY", Value = Model.Length_QTY==null?0:Model.Length_QTY},
            new SqlParameter { ParameterName = "@Estimated_Cost", Value = Model.Estimated_Cost==null?0:Model.Estimated_Cost},
            new SqlParameter { ParameterName = "@GO_Date", Value = Model.GO_Date??string.Empty },
            new SqlParameter { ParameterName = "@GO_No", Value = Model.GO_No??string.Empty },
            new SqlParameter { ParameterName = "@Sanctioned_Date", Value = Model.Sanctioned_Date??string.Empty },
            new SqlParameter { ParameterName = "@Sanctioned_LNo", Value = Model.Sanctioned_LNo??string.Empty },
            new SqlParameter { ParameterName = "@Sanctioned_Amount", Value = Model.Sanctioned_Amount==null?0:Model.Sanctioned_Amount},
            new SqlParameter { ParameterName = "@Start_Date", Value = Model.Start_Date??string.Empty },
            new SqlParameter { ParameterName = "@Target_Date", Value = Model.Target_Date??string.Empty },
            new SqlParameter { ParameterName = "@Expected_End_Date", Value = Model.Expected_End_Date??string.Empty },
            new SqlParameter { ParameterName = "@Actual_End_Date", Value = Model.Actual_End_Date??string.Empty },
            new SqlParameter { ParameterName = "@Handover_Date", Value = Model.Handover_Date??string.Empty },
            new SqlParameter { ParameterName = "@Work_Status", Value = Model.Work_Status??string.Empty },
            new SqlParameter { ParameterName = "@Scheme_Name", Value = Model.Scheme_Name??string.Empty },
            new SqlParameter { ParameterName = "@Release_Amount", Value = Model.Release_Amount==null?0:Model.Release_Amount},
            new SqlParameter { ParameterName = "@Release_Amount_Date", Value = Model.Release_Amount_Date??string.Empty },
            new SqlParameter { ParameterName = "@Release_Amount_LNo", Value = Model.Release_Amount_LNo??string.Empty },
            new SqlParameter { ParameterName = "@RemainRel_Amount", Value = Model.RemainRel_Amount==null?0:Model.RemainRel_Amount},
            new SqlParameter { ParameterName = "@Remark", Value = Model.Remark??string.Empty },
            new SqlParameter { ParameterName = "@Longitude", Value = Model.Longitude??string.Empty },
            new SqlParameter { ParameterName = "@Latitude", Value = Model.Latitude??string.Empty },
            new SqlParameter { ParameterName = "@CMISProjectCode", Value = Model.CMISProjectCode??string.Empty },
            new SqlParameter { ParameterName = "@CMISPwd", Value = Model.CMISPwd??string.Empty },
            new SqlParameter { ParameterName = "@TenderStatusId", Value = Model.TenderStatusId==null?0:Model.TenderStatusId},
            new SqlParameter { ParameterName = "@TenderRemark", Value = Model.TenderRemark??string.Empty },
            new SqlParameter { ParameterName = "@ApprovalDate", Value = Model.ApprovalDate??string.Empty },
            new SqlParameter { ParameterName = "@ParliamentId", Value = Model.ParliamentId==null?0:Model.ParliamentId},
            new SqlParameter { ParameterName = "@COnstituencyId", Value = Model.COnstituencyId==null?0:Model.COnstituencyId},
            new SqlParameter { ParameterName = "@ProjectCategoryId", Value = Model.ProjectCategoryId==null?0:Model.ProjectCategoryId},
            new SqlParameter { ParameterName = "@CMISWork_Type_ID", Value = Model.CMISWork_Type_ID==null?0:Model.CMISWork_Type_ID},
            new SqlParameter { ParameterName = "@ProcID", Value = Model.ProcId}
            };
            var sqlQaury = @"Proc_CMISProjectMaster @Work_ID,@Program_ID,@Division_ID,@Work_Type_ID,@ZoneId,@CircleId,@DepartmentId,@VikasKhand_ID,@Work_Name,@NoOfWork,
@Length_QTY,@Estimated_Cost,@GO_Date,@GO_No,@Sanctioned_Date,@Sanctioned_LNo,@Sanctioned_Amount,@Start_Date,@Target_Date,@Expected_End_Date,
@Actual_End_Date,@Handover_Date,@Work_Status,@Scheme_Name,@Release_Amount,@Release_Amount_Date,@Release_Amount_LNo,@RemainRel_Amount,
@Remark,@Longitude,@Latitude,@CMISProjectCode,@CMISPwd,@TenderStatusId,@TenderRemark,@ApprovalDate,@ParliamentId,@COnstituencyId,@ProjectCategoryId,@CMISWork_Type_ID,@ProcId";
            var IList = this.Database.SqlQuery<ProjectMaster>(sqlQaury, sqlParams);
            return IList;
        }
        #endregion
        public IEnumerable<WorkModel> WorkDetails(WorkModel Model)
        {

            var param = new SqlParameter[]
            {
            new SqlParameter{ParameterName="@ProcID",Value=Model.ProcId==null?0:Model.ProcId},
            new SqlParameter{ParameterName="@WorkId",Value=Model.WorkId==null?0:Model.WorkId},
            new SqlParameter{ParameterName="@ZoneId",Value=Model.ZoneId==null?0:Model.ZoneId},
            new SqlParameter{ParameterName="@CircleId",Value=Model.CircleId==null?0:Model.CircleId},
            new SqlParameter{ParameterName="@DivisionId",Value=Model.DivisionId==null?0:Model.DivisionId},
            new SqlParameter{ParameterName="@DepartmentId",Value=Model.DepartmentId==null?0:Model.DepartmentId},
            new SqlParameter{ParameterName="@ProgramId",Value=Model.ProgramId==null?0:Model.ProgramId},
            new SqlParameter{ParameterName="@WTypeId",Value=Model.WTypeId==null?0:Model.WTypeId},
            new SqlParameter{ParameterName="@Work",Value=Model.Work ?? string.Empty},
            new SqlParameter{ParameterName="@BlockId",Value=Model.BlockId==null?0:Model.BlockId },
            new SqlParameter{ParameterName="@NoOfWork",Value=Model.NoOfWork==null?0:Model.NoOfWork},
            new SqlParameter{ParameterName="@Length",Value=Model.Length==null?0:Model.Length},
            new SqlParameter{ParameterName="@SanctionedDate",Value=Model.SanctionedDate??string.Empty},
            new SqlParameter{ParameterName="@SanctionedAMt",Value=Model.SanctionedAMt==null?0:Model.SanctionedAMt},
            new SqlParameter{ParameterName="@StartDate",Value=Model.StartDate ?? string.Empty},
            new SqlParameter{ParameterName="@completedDate",Value=Model.completedDate??string.Empty},
            new SqlParameter{ParameterName="@HandOverDate",Value=Model.HandOverDate??string.Empty},
            new SqlParameter{ParameterName="@Assembly",Value=Model.Assembly??string.Empty},
            new SqlParameter{ParameterName="@DistrictId",Value=Model.DistrictId==null?0:Model.DistrictId},
            new SqlParameter{ParameterName="@Scheme",Value=Model.Scheme??string.Empty},
            new SqlParameter{ParameterName="@EstimateCost",Value=Model.EstimateCost==null?0:Model.EstimateCost},
            new SqlParameter{ParameterName="@SanctionedAmtLaterNo",Value=Model.SanctionedAmtLaterNo??string.Empty},
            new SqlParameter{ParameterName="@ReleasedAmtLaterNo",Value=Model.ReleasedAmtLaterNo??string.Empty},
            new SqlParameter{ParameterName="@ReleasedDate",Value=Model.ReleasedDate??string.Empty},
            new SqlParameter{ParameterName="@Longitude",Value=Model.Longitude??string.Empty},
            new SqlParameter{ParameterName="@Latitude",Value=Model.Latitude??string.Empty},
            new SqlParameter{ParameterName="@Remark",Value=Model.Remark??string.Empty},
            new SqlParameter{ParameterName="@CMISProjectCode",Value=Model.CMISProjectCode??string.Empty},
            new SqlParameter{ParameterName="@CMISPwd",Value=Model.CMISPwd??string.Empty},
            };
            // var query = @"Proc_WorkDetails @ProcID,@WorkId,@ZoneId,@CircleId,@DivisionId,@DepartmentId,@ProgramId,
            //@WTypeId,@Work,@BlockId,@NoOfWork,@Length,@SanctionedDate,@SanctionedAMt,@StartDate,@completedDate,
            //@HandOverDate,@Assembly,@DistrictId,@ReleasedAmtLaterNo,@SanctionedAmtLaterNo,@EstimateCost,@Scheme,@Remark,@Latitude,@Longitude,@ReleasedDate,@CMISProjectCode,@CMISPwd";
            var query = @"Proc_BindMaster @ProcId";
            return this.Database.SqlQuery<WorkModel>(query, param);
        }

        #region AmitSrivastava
        public IEnumerable<ProjectProgress> WorkProgress(ProjectProgress Model)
        {
            var param = new SqlParameter[]{
            new SqlParameter{ParameterName="@Id",Value=Model.Id==null?0:Model.Id},
            new SqlParameter{ParameterName="@ProjectId",Value=Model.ProjectId==null?0:Model.ProjectId},
            new SqlParameter{ParameterName="@ZoneId",Value=Model.ZoneId==null?0:Model.ZoneId},
            new SqlParameter{ParameterName="@CircleId",Value=Model.CircleId==null?0:Model.CircleId},
            new SqlParameter{ParameterName="@WorkId",Value=Model.WorkId==null?0:Model.WorkId},
            new SqlParameter{ParameterName="@BlockId",Value=Model.BlockId==null?0:Model.BlockId},
            new SqlParameter{ParameterName="@DistrictId",Value=Model.DistrictId==null?0:Model.DistrictId},
            new SqlParameter{ParameterName="@DevelopmentblockId",Value=Model.DevelopmentblockId==null?0:Model.DevelopmentblockId},
            new SqlParameter{ParameterName="@DepartmentId",Value=Model.DepartmentId==null?0:Model.DepartmentId},
            new SqlParameter{ParameterName="@SchemeId",Value=Model.SchemeId==null?0:Model.SchemeId},
            new SqlParameter{ParameterName="@MonthId",Value=Model.MonthId==null?0:Model.MonthId},
            new SqlParameter{ParameterName="@YearId",Value=Model.YearId==null?0:Model.YearId},
            new SqlParameter{ParameterName="@WorkFor",Value=Model.WorkFor==null?0:Model.WorkFor},
            new SqlParameter{ParameterName="@WorkName",Value=Model.WorkName??string.Empty},
            new SqlParameter{ParameterName="@WorkstartDate",Value=Model.WorkstartDate??string.Empty},
            new SqlParameter{ParameterName="@ProbableWorkComDate",Value=Model.ProbableWorkComDate??string.Empty},
            new SqlParameter{ParameterName="@ApprovalDate",Value=Model.ApprovalDate??string.Empty},
            new SqlParameter{ParameterName="@ApprovalCost",Value=Model.ApprovalCost==null?0:Model.ApprovalCost},
            new SqlParameter{ParameterName="@NoOfWork",Value=Model.NoOfWork ?? string.Empty},
            new SqlParameter{ParameterName="@ReleasedAmt",Value=Model.ReleasedAmt==null?0:Model.ReleasedAmt},
            new SqlParameter{ParameterName="@MonthlyReceivedAmt",Value=Model.MonthlyReceivedAmt==null?0:Model.MonthlyReceivedAmt},
            new SqlParameter{ParameterName="@Transferdate",Value=Model.Transferdate??string.Empty},
            new SqlParameter{ParameterName="@FinancialProgress",Value=Model.FinancialProgress==null?0:Model.FinancialProgress},
            new SqlParameter{ParameterName="@TotalreceivedAmt",Value=Model.TotalreceivedAmt==null?0:Model.TotalreceivedAmt},
            new SqlParameter{ParameterName="@ActualComWorkdate",Value=Model.ActualComWorkdate??string.Empty},
            new SqlParameter{ParameterName="@MonthlyExpenditureFinProgress",Value=Model.MonthlyExpenditureFinProgress==null?0:Model.MonthlyExpenditureFinProgress},
            new SqlParameter{ParameterName="@PhysicalProgress",Value=Model.PhysicalProgress==null?0:Model.PhysicalProgress},
            new SqlParameter{ParameterName="@UpdateStatusId",Value=Model.UpdateStatusId==null?0:Model.UpdateStatusId},
            new SqlParameter{ParameterName="@BuildingRemark",Value=Model.BuildingRemark??string.Empty},
            new SqlParameter{ParameterName="@Length",Value=Model.Length==null?0:Model.Length},
            new SqlParameter{ParameterName="@UpdateStatusRoadId",Value=Model.UpdateStatusRoadId==null?0:Model.UpdateStatusRoadId},
            new SqlParameter{ParameterName="@UpdateStatusCulverId",Value=Model.UpdateStatusCulverId==null?0:Model.UpdateStatusCulverId},
            new SqlParameter{ParameterName="@ActualLength",Value=Model.ActualLength==null?0:Model.ActualLength},
            new SqlParameter{ParameterName="@SoilDrain",Value=Model.SoilDrain??string.Empty},
            new SqlParameter{ParameterName="@G1",Value=Model.G1==null?0:Model.G1},
            new SqlParameter{ParameterName="@G2",Value=Model.G2==null?0:Model.G2},
            new SqlParameter{ParameterName="@G3",Value=Model.G3==null?0:Model.G3},
            new SqlParameter{ParameterName="@lepan",Value=Model.lepan==null?0:Model.lepan},
            new SqlParameter{ParameterName="@Target",Value=Model.Target==null?0:Model.Target},
            new SqlParameter{ParameterName="@Complete",Value=Model.Complete==null?0:Model.Complete},
            new SqlParameter{ParameterName="@Processing",Value=Model.Processing==null?0:Model.Processing},
            new SqlParameter{ParameterName="@NotStartwork",Value=Model.NotStartwork==null?0:Model.NotStartwork},
            new SqlParameter{ParameterName="@Cancle",Value=Model.Cancle==null?0:Model.Cancle},
            new SqlParameter{ParameterName="@Remark",Value=Model.Remark??string.Empty},
            new SqlParameter{ParameterName="@CMISProjectCode",Value=Model.CMISProjectCode??string.Empty},
            new SqlParameter{ParameterName="@CMISPwd",Value=Model.CMISPwd??string.Empty},
            new SqlParameter{ParameterName="@ProcId",Value=Model.ProcId==null?0:Model.ProcId}
            };
            var query = @"Proc_ProjectProgress @Id,@ProjectId,@ZoneId,@CircleId,@WorkId,@BlockId,@DistrictId,@DevelopmentblockId,
                        @DepartmentId,@SchemeId,@MonthId,@YearId,@WorkFor,@WorkName,@WorkstartDate,
                        @ProbableWorkComDate,@ApprovalDate,@ApprovalCost,@NoOfWork,@ReleasedAmt,
                        @MonthlyReceivedAmt,@Transferdate,@FinancialProgress,@TotalreceivedAmt,@ActualComWorkdate,
                        @MonthlyExpenditureFinProgress,@PhysicalProgress,@UpdateStatusId,@BuildingRemark,
                        @Length,@UpdateStatusRoadId,@UpdateStatusCulverId,@ActualLength,@SoilDrain,@G1,
                        @G2,@G3,@lepan,@Target,@Complete,@Processing,@NotStartwork,@Cancle,@Remark,@CMISProjectCode,@CMISPwd,@ProcId";
            return this.Database.SqlQuery<ProjectProgress>(query, param);
        }

        public IEnumerable<ActivityDetail> ActivityDetail(ActivityDetail Model)
        {
            var param = new SqlParameter[]{
            new SqlParameter{ParameterName="@ActivityId",Value=Model.ActivityId==null?0:Model.ActivityId},
            new SqlParameter{ParameterName="@ProjectId",Value=Model.ProjectId==null?0:Model.ProjectId},
            new SqlParameter{ParameterName="@OfficeId",Value=Model.OfficeId==null?0:Model.OfficeId},
            new SqlParameter{ParameterName="@DistrictId",Value=Model.DistrictId==null?0:Model.DistrictId},
            new SqlParameter{ParameterName="@DepartmentId",Value=Model.DepartmentId==null?0:Model.DepartmentId},
            new SqlParameter{ParameterName="@ActivityHeading",Value=Model.ActivityHeading??string.Empty},
            new SqlParameter{ParameterName="@ActivityWaitage",Value=Model.ActivityWaitage==null?0:Model.ActivityWaitage},
            new SqlParameter{ParameterName="@StartDt",Value=Model.StartDt??string.Empty},
            new SqlParameter{ParameterName="@EndDt",Value=Model.EndDt??string.Empty},
            new SqlParameter{ParameterName="@CMISProjectCode",Value=Model.CMISProjectCode??string.Empty},
            new SqlParameter{ParameterName="@CMISPwd",Value=Model.CMISPwd??string.Empty},
            new SqlParameter{ParameterName="@ProcId",Value=Model.ProcId==null?0:Model.ProcId},
            new SqlParameter{ParameterName="@CMISActivityId",Value=Model.CMISActivityId??string.Empty},
            };
            var query = @"Proc_ActivityDetail @ActivityId,@ProjectId,@OfficeId,@DistrictId,
                        @DepartmentId,@ActivityHeading,@ActivityWaitage,@StartDt,@EndDt,
                        @CMISProjectCode,@CMISPwd,@ProcId,@CMISActivityId";
            return this.Database.SqlQuery<ActivityDetail>(query, param);
        }
        public IEnumerable<SubActivityDetails> Proc_SubActivityDetails(SubActivityDetails Model)
        {
            var param = new SqlParameter[]{
            new SqlParameter{ParameterName="@SubActId",Value=Model.SubActId==null?0:Model.SubActId},
            new SqlParameter{ParameterName="@ActivityId",Value=Model.ActivityId==null?0:Model.ActivityId},
            new SqlParameter{ParameterName="@CMISActId",Value=Model.CMISActId??string.Empty},
            new SqlParameter{ParameterName="@SubActWeightage",Value=Model.SubActWeightage==null?0:Model.SubActWeightage},
            new SqlParameter{ParameterName="@cmdType",Value=Model.cmdType??string.Empty},
            new SqlParameter{ParameterName="@CMISProjectCode",Value=Model.CMISProjectCode??string.Empty},
            new SqlParameter{ParameterName="@SubActHeading",Value=Model.SubActHeading??string.Empty},
            new SqlParameter{ParameterName="@WorkStartDt",Value=Model.WorkStartDt??string.Empty},
            new SqlParameter{ParameterName="@WorkEndDt",Value=Model.WorkEndDt??string.Empty},
            new SqlParameter{ParameterName="@IPAddress",Value=Model.IPAddress??string.Empty},
            new SqlParameter{ParameterName="@UserId",Value=Model.UserId==null?0:Model.UserId},
            new SqlParameter{ParameterName="@CMISSubActId",Value=Model.CMISSubActId==null?0:Model.CMISSubActId},
            new SqlParameter{ParameterName="@ProcId",Value=Model.ProcId==null?0:Model.ProcId}
            };
            var query = @"Proc_SubActivityDetails @SubActId,@ActivityId,@CMISActId,@SubActWeightage,@cmdType,@CMISProjectCode,@SubActHeading,@WorkStartDt,@WorkEndDt,@IPAddress,@UserId,@CMISSubActId,@ProcId";
            return this.Database.SqlQuery<SubActivityDetails>(query, param);
        }
        #endregion
        #region Old Project Report
        public IEnumerable<OldProjectReport> Proc_OldProjectReport(OldProjectReport Model)
        {

            var param = new SqlParameter[]
            {
            
            new SqlParameter{ParameterName="@WorkId",Value=Model.WorkId==null?0:Model.WorkId},
            new SqlParameter{ParameterName="@ZoneId",Value=Model.ZoneId==null?0:Model.ZoneId},
            new SqlParameter{ParameterName="@CircleId",Value=Model.CircleId==null?0:Model.CircleId},
            new SqlParameter{ParameterName="@DistrictId",Value=Model.DistrictId==null?0:Model.DistrictId},
            new SqlParameter{ParameterName="@VikashkhandId",Value=Model.VikashkhandId==null?0:Model.VikashkhandId},
            new SqlParameter{ParameterName="@ProgramId",Value=Model.ProgramId==null?0:Model.ProgramId},
            new SqlParameter{ParameterName="@WorkTypeId",Value=Model.WorkTypeId==null?0:Model.WorkTypeId},
            new SqlParameter{ParameterName="@FromCost",Value=Model.FromCost==null?0:Model.FromCost},
            new SqlParameter{ParameterName="@ToCost",Value=Model.ToCost==null?0:Model.ToCost},
            new SqlParameter{ParameterName="@FromDate",Value=Model.FromDate ?? string.Empty},
            new SqlParameter{ParameterName="@ToDate",Value=Model.ToDate ?? string.Empty},
            new SqlParameter{ParameterName="@ProcId",Value=Model.ProcId==null?0:Model.ProcId},
            };
            var query = @"Proc_OldProjectReport @WorkId,@ZoneId,@CircleId,@DistrictId,@VikashkhandId,
                 @ProgramId,@WorkTypeId,@FromCost,@ToCost,@FromDate,@ToDate,@ProcId";

            return this.Database.SqlQuery<OldProjectReport>(query, param);
        }
        #endregion

    }
}