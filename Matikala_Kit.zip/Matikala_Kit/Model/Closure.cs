﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace Matikala.Models
{
    public class Closure
    {
        public int Id { get; set; }
        public int StateId { get; set; }
        public int DistrictId { get; set; }
        public int UserTypeId { get; set; }
        public int ExpinTrand { get; set; }
        public string ToolkitName { get; set; }
        public string ApplicationReceiveDate { get; set; }
        public string InterViewDate { get; set; }
        public string ClosureDate { get; set; }
        public string SchemeCode { get; set; }
        public string DistrictName { get; set; }
        public string SchemeName { get; set; }
        public int ProcId { get; set; }
        public string msg { get; set; }
        public string StatusForApplicant { get; set; }
        public string ApplicantName { get; set; }
        public string FinYear { get; set; }
        public string ListJson { get; set; }
        public string ApplicationId { get; set; }
        public string AadharNo { get; set; }
        public string UpdatedId { get; set; }
        public string UserName { get; set; }
        public string UPassword { get; set; }
        public string LockStatus { get; set; }

    }
}