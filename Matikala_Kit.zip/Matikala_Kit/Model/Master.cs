﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Matikala.DBLayer;

namespace Matikala.Models
{
    public class Master
    {
        public int MasterId { get; set; }
        public string MasterName { get; set; }
        public string MasterCode { get; set; }
        public string ParameterName { get; set; }
        public int ParameterId { get; set; }
        public string Criteria { get; set; }
        public int MaximumMarks { get; set; }
        public int Marks { get; set; }
    }
    public class MasterData
    {
        DB_Layer db = new DB_Layer();
        #region LoadMaster
        public SelectList LoadMaster(int procid)
        {
            return new SelectList(db.Proc_BindMaster(procid).ToList(), "MasterId", "MasterName");
        }
        public SelectList LoadMasterbyCode(int procid)
        {
            return new SelectList(db.Proc_BindMaster(procid).ToList(), "MasterCode", "MasterName");
        }
        public SelectList LoadMasterById(int procid, int id)
        {
            return new SelectList(db.Proc_BindMasterById(procid, id).ToList(), "MasterId", "MasterName");
        }
        #endregion
    }
}

